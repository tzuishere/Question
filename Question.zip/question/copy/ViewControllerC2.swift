import UIKit

class ViewControllerC2: UIViewController
{
    var firstVCC2: ViewControllerC1!
    var homeVCC: HomeViewController!
    
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var myGifView: UIImageView!
    
    var scroeC2:Int = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        scoreLabel.text = "您總共答對\(scroeC2)題"
        myGifView.loadGif(name: "handclap")
    }
    
    @IBAction func buttonHome(_ sender: UIButton)
    {
        self.dismiss(animated: false)
        {
            self.firstVCC2.dismiss(animated: false)
        }
    }
}
