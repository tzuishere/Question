import UIKit

struct Question {
    let question: String
    let options: [String]
    let correctAnswer:Int
}

class ViewControllerA1: UIViewController
{
    var homeVCA:HomeViewController!
    
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet var optionButtons: [UIButton]!
    
    var score = 0
    var questions:[Question] = []
    var currentQuestionIndex = 0
    {
        didSet { loadQuestion() }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupQuestions()
        loadQuestion()
    }

    func setupQuestions() {
        questions = [
            Question(question: "I've always had an _____ in history.", options: ["interest","interests","interesting","interested"], correctAnswer: 1),
            Question(question: "The teacher _____ well with the students.", options: ["interacts","reacts","exact","acts"], correctAnswer: 0),
            Question(question: "Many supporters _____ with his politics.", options: ["disappear","discover","disagree","disclose"], correctAnswer: 2),
            Question(question: "Be _____ not to burn the roof of your mouth.", options: ["peaceful","careful","useful","respectful"], correctAnswer: 3),
            Question(question: "If the problem still _____ , you can ask your teacher.", options: ["insists","persists","subsists","assists"], correctAnswer: 1),
            Question(question: "The three actors were  _____  different roles.", options: ["assigned","designed","resigned","consigned"], correctAnswer: 0),
            Question(question: "According to the weather _____ ,it will rain tomorrow.", options: ["foresee","forehead","foreword","forecast"], correctAnswer: 3),
            Question(question: "The students are _____ about the complicated question.", options: ["confusing ","confused","confuse","confusion"], correctAnswer: 1),
            Question(question: "A laptop is _____ when I'm working in the coffee shop.", options: ["using","use","useful","usage"], correctAnswer: 2),
            Question(question: "He has a lot _____ for the local volunteers.", options: ["expect","inspect","prospect","respect"], correctAnswer: 3),
            ]
        questions.shuffle()
        }
    
    func loadQuestion()
    {
        if currentQuestionIndex < 10
        {
            let question = questions[currentQuestionIndex]
            questionLabel.text = question.question
            numberLabel.text = "題目 \(currentQuestionIndex + 1) / 10"
            
            for (index, optionButton) in optionButtons.enumerated()
            {
                optionButton.setTitle(question.options[index], for: .normal)
            }
        }
        else
        {
            self.performSegue(withIdentifier: "showResultSegueA", sender: nil)
        }
    }
    
    @IBAction func optionButtonTapped(_ sender: UIButton)
    {
        guard let selectedIndex = optionButtons.firstIndex(of: sender)
                
        else { return }
        
        let question = questions[currentQuestionIndex]
        
        if question.correctAnswer == selectedIndex
        {
            score += 1
        }
        currentQuestionIndex += 1
    }

    @IBSegueAction func resultSegueActionA(_ coder: NSCoder) -> ViewControllerA2?
    {
        let viewControllerA2 = ViewControllerA2(coder: coder)
        viewControllerA2?.scroe = self.score
        return viewControllerA2
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let secondVCA = segue.destination as! ViewControllerA2
        
        secondVCA.homeVCA = homeVCA
        secondVCA.firstVCA2 = self
    }
}
