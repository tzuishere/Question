import UIKit

struct QuestionB {
    let pic: String
    let options: [String]
    let correctAnswer:Int
}

class ViewControllerB1: UIViewController
{
    var homeVCB: HomeViewController!
    
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet var optionButtons: [UIButton]!
    @IBOutlet weak var imgView: UIImageView!
    
    var score = 0
    var questions:[QuestionB] = []
    var currentQuestionIndex = 0
    {
        didSet { loadQuestion() }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setupQuestions()
        loadQuestion()
    }
    
    func setupQuestions()
    {
        questions = [
            QuestionB(pic: "neighbor", options: ["doctor" , "administrator", "neighbor", "inspector"], correctAnswer: 2),
            QuestionB(pic: "oversleep", options: ["oversleep" ,"overflow", "overlook", "overwork"], correctAnswer: 0),
            QuestionB(pic: "intersection", options: ["intermediate" ,"intersection", "internet", "international"], correctAnswer: 1),
            QuestionB(pic: "bankrupt", options: ["interrupt" ,"irrupt", "disrupt", "bankrupt"], correctAnswer: 3),
            QuestionB(pic: "upward", options: ["backward" ,"upward", "downward ", "westward"], correctAnswer: 1),
            QuestionB(pic: "athletics", options: ["tactics" ,"athletics", "economics", "statistics"], correctAnswer: 1),
            QuestionB(pic: "impatient", options: ["impatient" ,"immutable ", "impartial ", "impulsive "], correctAnswer: 0),
            QuestionB(pic: "shore", options: ["chore" ,"score", "shawl", "shore"], correctAnswer: 3),
            QuestionB(pic: "expect", options: ["except" ,"expand", "expect ", " expend"], correctAnswer: 2),
            QuestionB(pic: "contact", options: ["contact" ,"contract", "contrast", "content"], correctAnswer: 0),
        ]
        for (index, question) in questions.enumerated()
        {
            var option = question.options
            option.shuffle()
            
            let newQuestion = QuestionB(
                pic: question.pic,
                options: option,
                correctAnswer: option.firstIndex(of: question.options[question.correctAnswer])!
            )
            questions[index] = newQuestion
        }
         
    }
    
    func loadQuestion()
    {
        if currentQuestionIndex < 10
        {
            let question = questions[currentQuestionIndex]
            numberLabel.text = "題目 \(currentQuestionIndex + 1) / 10"
            
            for (index, optionButton) in optionButtons.enumerated()
            {
                optionButton.setTitle(question.options[index], for: .normal)
            }
            imgView.image = UIImage(named: question.pic)
        }
        else {
            self.performSegue(withIdentifier: "showResultSegueB", sender: nil)
        }
    }
    
    @IBAction func optionButtonTapped(_ sender: UIButton)
    {
        guard let selectedIndex = optionButtons.firstIndex(of: sender)
                
        else { return }
        
        let question = questions[currentQuestionIndex]
        
        if question.correctAnswer == selectedIndex
        {
            score += 1
        }
        currentQuestionIndex += 1
    }

    @IBSegueAction func resultSegueActioB(_ coder: NSCoder) ->  ViewControllerB2?
    {
        let viewControllerB2 = ViewControllerB2(coder: coder)
        
        viewControllerB2?.scroe = self.score
        return viewControllerB2
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let secondVCB = segue.destination as! ViewControllerB2
        
        secondVCB.homeVCB = homeVCB
        secondVCB.firstVCB2 = self
    }
}

