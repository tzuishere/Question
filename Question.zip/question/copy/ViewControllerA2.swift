import UIKit

class ViewControllerA2: UIViewController
{
    var firstVCA2: ViewControllerA1!
    var homeVCA: HomeViewController!
    
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var myGifView: UIImageView!
    
    var scroe:Int = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        scoreLabel.text = "\(scroe)"
        myGifView.loadGif(name: "gogo")
    }
    
    @IBAction func buttonHome(_ sender: UIButton)
    {
        self.dismiss(animated: false)
        {
//            self.navigationController?.popViewController(animated: false)
//            self.firstVC.navigationController?.popViewController(animated: false)
            self.firstVCA2.dismiss(animated: false)
        }
    }
}
