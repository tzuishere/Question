import UIKit

class HomeViewController: UIViewController
{

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if let firstVCA1 = segue.destination as? ViewControllerA1
        {
            firstVCA1.homeVCA = self
        }
        else if let firstVCB1 = segue.destination as? ViewControllerB1
        {
            firstVCB1.homeVCB = self
        }
    }
}
