import UIKit

class ViewControllerB2: UIViewController
{
    var firstVCB2: ViewControllerB1!
    var homeVCB: HomeViewController!
    
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var myGifView: UIImageView!
    
    var scroe:Int = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        scoreLabel.text = "\(scroe)"
        myGifView.loadGif(name: "jump")
    }
    
    @IBAction func buttonHome(_ sender: UIButton)
    {
        self.dismiss(animated: false)
        {
            self.firstVCB2.dismiss(animated: false)
        }
    }
}
