import UIKit
import AVFoundation

struct QuestionC {
    let audio: String
    let options: [String]
    let correctAnswer:Int
}

class ViewControllerC1: UIViewController
{
    var player: AVAudioPlayer!
    var homeVCC: HomeViewController!
    
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet var optionButtons: [UIButton]!
    
    var scoreC1 = 0
    var questions:[QuestionC] = []
    var currentQuestionIndex = 0
    {
        didSet { loadQuestion() }
    }
    
    func setupQuestions()
    {
        questions = [
            QuestionC(audio: "adapt", options: ["accept 接受" , "adopt 領養", "adapt 適應", "advice 建議"], correctAnswer: 2),
            QuestionC(audio: "alter", options: ["alter 改變" ,"other 其他的", "alternative 選擇", "elder 年長的"], correctAnswer: 0),
            QuestionC(audio: "backward", options: ["upward 朝上的" ,"downward 往下的", "forward 往前的", "backward 向後的"], correctAnswer: 3),
            QuestionC(audio: "compete", options: ["comment 評論" ,"complete 完成", "compete 競爭", "complain 抱怨"], correctAnswer: 2),
            QuestionC(audio: "contract", options: ["concept 概念" ,"contract 合約", "contact 接觸", "contrast 對比"], correctAnswer: 1),
            QuestionC(audio: "dedicate", options: ["delicate 精美的" ,"deduct 扣除", "descent 向下", "dedicate 奉獻"], correctAnswer: 3),
            QuestionC(audio: "ensure", options: ["ensure 確保" ,"make sure 確保", "unsure 不確定", "assure 保證"], correctAnswer: 0),
            QuestionC(audio: "introduce", options: ["reduce 減少" ,"conduce 導致", "introduce 介紹", "induce 誘發"], correctAnswer: 2),
            QuestionC(audio: "propose", options: ["propose 提案" ,"provide 提供", "provide 提供", "purpose 目的"], correctAnswer: 0),
            QuestionC(audio: "shore", options: ["share 分享" ,"shore 岸邊", "chore 瑣事", "chord 和音"], correctAnswer: 1)
        ]
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setupQuestions()
        loadQuestion()
    }
    
    
    @IBAction func audioButton(_ sender: UIButton)
    {
        let question = questions[currentQuestionIndex]
        playAudio(named: question.audio)
    }
    
    func loadQuestion()
    {
        if currentQuestionIndex < 10
        {
            let question = questions[currentQuestionIndex]
            numberLabel.text = "題目 \(currentQuestionIndex + 1) / 10"
            
            for (index, optionButton) in optionButtons.enumerated()
            {
                optionButton.setTitle(question.options[index], for: .normal)
            }
        }
        else
        {
            self.performSegue(withIdentifier: "showResultSegueC", sender: nil)
        }
    }
    
    func playAudio(named fileName: String)
    {
        guard let soundURL = Bundle.main.url(forResource: fileName, withExtension: "mp3") else
        {
            print("Sound file not found.")
            return
        }
        
        do{
            player = try AVAudioPlayer(contentsOf: soundURL)
            player.play()
        }
        catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }
    
    @IBAction func optionButton(_ sender: UIButton)
    {
        guard let selectedIndex = optionButtons.firstIndex(of: sender)
                
        else { return }
        
        let question = questions[currentQuestionIndex]
        
        if question.correctAnswer == selectedIndex
        {
            scoreC1 += 1
        }
        currentQuestionIndex += 1
    }
    
    @IBSegueAction func resultSegueActionC(_ coder: NSCoder) -> ViewControllerC2?
    {
        let viewControllerC2 = ViewControllerC2(coder: coder)
        
        viewControllerC2?.scroeC2 = self.scoreC1
        return viewControllerC2
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let secondVCC = segue.destination as! ViewControllerC2
        
        secondVCC.homeVCC = homeVCC
        secondVCC.firstVCC2 = self
    }
}
